package Notes;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import java.io.IOException;
import java.util.Date;
import javax.servlet.http.*;
public class NotesServlet extends HttpServlet {
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
                throws IOException {
	
	  String content = req.getParameter("content");
	  Date date = new Date();
	  Key key = KeyFactory.createKey("notes", "all");
	  Entity note = new Entity("note", key);
	  note.setProperty("date", date);
 	  note.setProperty("content", content);
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
        datastore.put(note);
        resp.sendRedirect("/notes.jsp");
    }
}
3. Файл конфігурації сервлету web.xml (Notes/war/WEB-INF/web.xml)
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE web-app PUBLIC
 "-//Sun Microsystems, Inc.//DTD Web Application 2.3//EN"
 "http://java.sun.com/dtd/web-app_2_3.dtd">
<web-app xmlns="http://java.sun.com/xml/ns/javaee" version="2.5">
    <servlet>
        <servlet-name>Notes</servlet-name>
        <servlet-class>Notes.NotesServlet</servlet-class>
    </servlet>
    <servlet-mapping>
        <servlet-name>Notes</servlet-name>
        <url-pattern>/Notes</url-pattern>
    </servlet-mapping>
    <welcome-file-list>
	<welcome-file>notes.jsp</welcome-file>
    </welcome-file-list>                
</web-app>
